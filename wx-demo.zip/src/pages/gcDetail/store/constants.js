export const GET_INIT_LIST_DATA = '/pages/gc/index/GET_INIT_LIST_DATA'
export const SWITCH_TOP_MENU_DATA = '/pages/gc/index/SWITCH_TOP_MENU_DATA'