export const HANDLE_SDBT_CHANGE = '/pages/releaseSd/HANDLE_SDBT_CHANGE'
