export const JFGZ_CHANGE = '/pages/user/MyPoints/JFGZ_CHANGE'
export const GET_INIT_LIST_DATA = '/pages/user/MyPoints/GET_INIT_LIST_DATA'
