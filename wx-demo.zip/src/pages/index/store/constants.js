export const GET_INIT_LIST_DATA = 'pages/index/index/GET_INIT_LIST_DATA'
export const SWITCH_FOOTER_MENU = 'pages/index/index/SWITCH_FOOTER_MENU'
export const SWITCH_TOP_MENU_DATA = 'pages/index/index/SWITCH_TOP_MENU_DATA'