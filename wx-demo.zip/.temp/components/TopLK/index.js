import Taro from '@tarojs/taro-h5';
import { Component } from "@tarojs/taro-h5";
import Nerv from "nervjs";
import { View, Image } from '@tarojs/components';

import './style.less';

class TopLK extends Component {

  render() {
    let { data, onClick } = this.props;
    return <View className="TopLK_wrap">
				{data.map((item, index) => {
        return <View key={index} className="item" onClick={onClick.bind(this, index)}>
								<Image src={item.imgUrl} />
								{item.text}
							</View>;
      })}
			</View>;
  }
}

export default TopLK;