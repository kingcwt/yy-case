export const HANDLE_PL_CHANGE = '/pages/pinglun/HANDLE_PL_CHANGE';
export const HANDLE_ISNM = '/pages/pinglun/HANDLE_ISNM';