import { constants } from './';
export const getInitListData = () => {
  let data = [{
    headerImg: '..',
    title: '森强金融',
    address: '朝阳区小营北路11号和泰大厦A座4层',
    url: '',
    createTime: '2019-2-2',
    num: '1' //类别
  }, {
    headerImg: '',
    title: '旺泰金控-鼎城典当',
    address: '朝阳区财富中心35和43层',
    url: '',
    createTime: '2019-2-2',
    num: '0' //类别
  }, {
    headerImg: '',
    title: '库容金福',
    address: '朝阳区小营北路11号和泰大厦A座4层',
    url: '',
    createTime: '2019-2-2',
    num: '3' //类别
  }, {
    headerImg: '',
    title: '华悦金服',
    address: '朝阳区亮马桥琨莎中心11层',
    url: '',
    createTime: '2019-2-2',
    num: '0' //类别
  }, {
    headerImg: '..',
    title: '森强金融',
    address: '朝阳区小营北路11号和泰大厦A座4层',
    url: '',
    createTime: '2019-2-2',
    num: '4' //类别
  }, {
    headerImg: '',
    title: '旺泰金控-鼎城典当',
    address: '朝阳区财富中心35和43层',
    url: '',
    createTime: '2019-2-2',
    num: '0' //类别
  }, {
    headerImg: '',
    title: '库容金福',
    address: '朝阳区小营北路11号和泰大厦A座4层',
    url: '',
    createTime: '2019-2-2',
    num: '0' //类别
  }, {
    headerImg: '',
    title: '华悦金服',
    address: '朝阳区亮马桥琨莎中心11层',
    url: '',
    createTime: '2019-2-2',
    num: '0' //类别
  }, {
    headerImg: '..',
    title: '森强金融',
    address: '朝阳区小营北路11号和泰大厦A座4层',
    url: '',
    createTime: '2019-2-2',
    num: '0' //类别
  }, {
    headerImg: '',
    title: '旺泰金控-鼎城典当',
    address: '朝阳区财富中心35和43层',
    url: '',
    createTime: '2019-2-2',
    num: '0' //类别
  }, {
    headerImg: '',
    title: '库容金福',
    address: '朝阳区小营北路11号和泰大厦A座4层',
    url: '',
    createTime: '2019-2-2',
    num: '0' //类别
  }, {
    headerImg: '',
    title: '华悦金服',
    address: '朝阳区亮马桥琨莎中心11层',
    url: '',
    createTime: '2019-2-2',
    num: '0' //类别
  }];
  return {
    type: constants.GET_INIT_LIST_DATA,
    payload: data
  };
};