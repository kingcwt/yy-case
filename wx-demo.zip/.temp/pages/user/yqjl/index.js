import Taro from '@tarojs/taro-h5';
import { Component } from "@tarojs/taro-h5";
import Nerv from "nervjs";
import { View, Text } from '@tarojs/components';

import TopInfo from '../../../components/TopInfo';
import '../style.less';

class Yqjl extends Component {

  config = {
    navigationBarTitleText: '邀请激励'
  };

  render() {
    return <View className="main my-yqjl">
				<TopInfo val="邀请激励" />		
				<View className="my-yqjl-info">我共邀请了<Text>0</Text>位粉丝</View>
				<Text className="dx">暂时没有邀请记录!</Text>
			</View>;
  }

  componentDidMount() {}

  componentDidShow() {}

}

export default Yqjl;